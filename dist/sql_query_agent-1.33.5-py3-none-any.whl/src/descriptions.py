"""Bottom-up description generation over the calculation DAG (ADR 0019).

A CTE is the smallest certified unit of business definition. Descriptions
are generated in topological order — every step's direct dependencies are
described before the step itself — then each metric's description is
composed from its ROOT steps' descriptions (summaries of summaries, never
raw SQL walls).

This module is pure orchestration: ordering, prompts, content-hash caching.
The LLM is a callback `describe(prompt) -> str`, so tests run with a fake,
devtools plugs in a local OpenAI-compatible endpoint, and production plugs
in the customer's Azure OpenAI — the Data Agent is a CONSUMER of these
descriptions, never the generator.

Grounding rule: a step's prompt contains its OWN sql fragment plus only the
names+descriptions of its direct dependencies (context, not content), so a
bad description cannot cascade up the chain.
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from typing import Callable

from src.graph.serialization import rows_to_edges, rows_to_nodes
from src.models import EdgeType, NodeLayer

# Bump when a prompt changes: the version is part of every cache key,
# so a prompt upgrade automatically regenerates every description on
# the next 07 run — no flags, no manual cache wipe (live find
# 2026-08-13: vague descriptions survived a rerun because the cache
# key knew only the SQL, not the prompt that read it).
# v3 (live find 2026-08-14): v2 kept actual values but also kept raw
# warehouse identifiers — the fix is grounded translation material
# (the data dictionary the graph already holds) plus a ban on raw
# identifiers in the output.
# v4 hardened the SQL-reading prompt after the fabrication trace.
# v5 (ADR 0044 phase 2, clauses 2+5): the SQL-reading step prompt is
# DELETED — the step path translates typed tree facts via
# src/tree/translate.py; the LLM never sees a SQL statement again.
# TREE_CONTRACT_VERSION rides in the version so tightening the tree
# contract regenerates everything it governs.
from src.tree import TREE_CONTRACT_VERSION
from src.tree.extract import build_decision_tree
from src.tree.translate import translate_tree

PROMPT_VERSION = f"5.t{TREE_CONTRACT_VERSION}"

MEASURE_PROMPT = (
    "You are documenting a Power BI DAX {expression_type} for a business "
    "audience of clinicians and executives.\n"
    "Measure name: {name}\n"
    "Defined in report: {report_name}\n"
    "{dict_block}"
    "DAX expression:\n{expression}\n\n"
    "Write ONE sentence (max 30 words) stating what this calculates in "
    "business terms. Then, if the DAX makes decisions, add one line per "
    "decision, each starting with '- ': filters, thresholds, time "
    "windows, and conditions. Keep the literal VALUES that define each "
    "decision — codes, numbers, statuses — with the business meaning "
    "beside each when the data dictionary above provides one. NEVER "
    "show raw table or column identifiers in the output — use the "
    "dictionary description or a plain phrase instead. Never write "
    "vague fillers such as 'specific', 'specified', 'certain', or "
    "'various' in place of a value. Ground every line in the DAX above. "
    "No patient identifiers, no preamble."
)

METRIC_PROMPT = (
    "You are documenting the certified business metric {metric_name}.\n"
    "Its calculation is assembled from these final steps (each already "
    "described in business terms):\n{roots_block}\n"
    "It draws on {step_count} calculation steps in total.\n\n"
    "Write a concise business description: first, one sentence stating "
    "what this metric reports or measures, grounded strictly in the step "
    "descriptions and the metric name. Then a blank line, then "
    "'Business logic:' followed by 3-6 bullets covering the population "
    "included, time windows, clinical criteria or thresholds, and how the "
    "outcome is calculated — in business terms, grounded ONLY in the step "
    "descriptions above. Bullets must keep the actual values, codes, "
    "thresholds, and time windows the step descriptions name — never "
    "generalize them away, and never write vague fillers such as "
    "'specific', 'specified', 'certain', or 'various' in place of a "
    "value. Do not state purposes, benefits, or decisions "
    "the metric supports unless a step description states them — no "
    "filler like 'supports decision-making' or 'improves outcomes'. "
    "Plain text only: no greetings, no markdown headers, no bold, no "
    "trailing spaces, no invented details."
)

# Observation only (never a retry loop): generated text that hides a
# value behind a filler word is flagged for the run report / dashboard.
_VAGUE_FILLERS = re.compile(
    r"\b(specific|specified|certain|various)\b", re.IGNORECASE)

# Raw-identifier smell in OUTPUT text: SNAKE_CASE_CAPS columns,
# #temp tables, backticked/dotted code refs (live find 2026-08-14:
# ADT_DEPARTMENT_ID / #SDX / `pd.PatEncCSNID` all over the workbench).
_RAW_IDENTIFIERS = re.compile(
    r"(#\w+|`[^`]+`|\b[A-Z][A-Z0-9]*(?:_[A-Z0-9]+)+\b)")




# --- The grounding gate (2026-08-19, TRACE_USP_ED_SEPSIS) -------------
# Field-proven failure modes in production descriptions: (1) SELECTed
# columns hallucinated into filters ("excludes pending or cancelled"
# with no such condition anywhere), (2) invented literal codes
# ("flowsheet IDs 123 and 456" vs the real 900112/900111). The prompt
# already forbade both; prompt instructions are intent — only
# mechanical verification survives (the notebook-contract lesson).

_OUT_NUMBERS = re.compile(r"\d{2,}")
_OUT_QUOTED = re.compile(r"'([^']{1,40})'")
_FILTER_CLAIM = re.compile(
    r"(?i)\b(exclud\w*|includes? only|only includ\w*|filters?\b|"
    r"requir\w+|must have|limited to|restrict\w*)\b")
_CLAIM_STOPWORDS = frozenset(
    "encounters includes include included excludes exclude excluded "
    "filters filter filtered records results patients patient orders "
    "information department departments emergency hospital associated "
    "between during where which their those based table tables step "
    "steps only that this with from have been were each every there "
    "measurements medications details specific specified certain "
    "various".split())


def _condition_text(fragment: str) -> str:
    """The parts of the SQL that actually DECIDE: windows of text after
    WHERE / ON / HAVING / AND / WHEN keywords. Approximate by design —
    used to tell 'filtered on' apart from 'merely selected'."""
    return " ".join(
        m.group(1)
        for m in re.finditer(
            r"(?is)\b(?:WHERE|HAVING|ON|AND|WHEN)\b(.{0,240})", fragment)
    )


def grounding_violations(
    text: str, fragment: str, dict_lines: "list[str] | None" = None
) -> "list[str]":
    """Deterministic checks of a generated description against the ONE
    source it claims to describe. Returns human-readable violations;
    empty list = grounded."""
    violations: "list[str]" = []
    ground = (fragment or "") + "\n" + "\n".join(dict_lines or [])
    ground_low = ground.lower()
    conditions = _condition_text(fragment or "").lower()

    # 1) every literal value in the output must exist in the source
    for num in set(_OUT_NUMBERS.findall(text)):
        if num not in ground:
            violations.append(f"ungrounded value: {num!r} not in the SQL")
    for quoted in set(_OUT_QUOTED.findall(text)):
        toks = _OUT_NUMBERS.findall(quoted)
        probe = toks[0] if toks else quoted
        if probe and probe.lower() not in ground_low:
            violations.append(f"ungrounded value: '{quoted}' not in the SQL")

    # 2) filter-claims need support in the DECIDING part of the SQL
    for line in text.splitlines():
        line = line.strip()
        if not line.startswith("- ") or not _FILTER_CLAIM.search(line):
            continue
        terms = [w for w in re.findall(r"[a-z]{5,}", line.lower())
                 if w not in _CLAIM_STOPWORDS]
        if not terms:
            continue
        in_fragment = [w for w in terms if w in ground_low]
        in_conditions = [w for w in in_fragment if w in conditions]
        has_literal = any(n in ground for n in _OUT_NUMBERS.findall(line))
        if not in_fragment and not has_literal:
            violations.append(f"ungrounded filter claim: {line!r}")
        elif in_fragment and not in_conditions and not has_literal:
            violations.append(
                f"selected-not-filtered: {line!r} — the concept appears "
                f"only in the SELECT list, never in a condition")
    return violations


def enforce_grounding(
    text: str, fragment: str, dict_lines: "list[str] | None" = None
) -> "tuple[str, list[str]]":
    """Surgical fallback after a failed retry: strip the violating
    lines, keep grounded content. If the remaining text still violates
    (bad summary sentence), drop everything — absence over fabrication.
    Returns (clean_text_or_empty, removed_violations)."""
    violations = grounding_violations(text, fragment, dict_lines)
    if not violations:
        return text, []
    bad_lines = {v.split(": ", 1)[1].split(" — ")[0].strip("'\"")
                 for v in violations if ": '" in v or ": \"" in v}
    kept = []
    for line in text.splitlines():
        if any(repr(line.strip()) == b or line.strip() == b.strip("'")
               for b in bad_lines):
            continue
        kept.append(line)
    cleaned = "\n".join(kept).strip()
    if cleaned and not grounding_violations(cleaned, fragment, dict_lines):
        return cleaned, violations
    return "", violations


def step_content_hash(fragment: str, dep_names: "list[str]",
                      dict_lines: "list[str] | None" = None) -> str:
    payload = (
        PROMPT_VERSION + "\n" + (fragment or "")
        + "\n--deps--\n" + "\n".join(sorted(dep_names))
        + "\n--dict--\n" + "\n".join(dict_lines or [])
    )
    return hashlib.sha256(payload.encode()).hexdigest()[:32]


def measure_content_hash(name: str, expression: str,
                         dict_lines: "list[str] | None" = None) -> str:
    payload = (
        PROMPT_VERSION + "\n--measure--\n" + name + "\n" + (expression or "")
        + "\n--dict--\n" + "\n".join(dict_lines or [])
    )
    return hashlib.sha256(payload.encode()).hexdigest()[:32]


def metric_content_hash(metric_name: str, roots: "list[tuple[str, str]]",
                        step_count: int) -> str:
    payload = (
        PROMPT_VERSION + "\n" + metric_name + f"\n{step_count}\n"
        + "\n".join(f"{n}\t{d}" for n, d in sorted(roots))
    )
    return hashlib.sha256(payload.encode()).hexdigest()[:32]


@dataclass
class DescriptionResult:
    descriptions: "dict[str, str]" = field(default_factory=dict)  # node_id -> text
    cache_hits: int = 0
    generated: int = 0
    failed: "list[str]" = field(default_factory=list)
    # (node_id, "reason_code: detail") — the WHY behind every failed
    # node, persisted to ops_fallout by 600 (field find 2026-08-20:
    # four failures whose causes existed only in printed output)
    failed_reasons: "list[tuple[str, str]]" = field(default_factory=list)
    vague: "list[str]" = field(default_factory=list)   # filler-word flags
    jargon: "list[str]" = field(default_factory=list)  # raw-identifier flags
    # grounding gate (2026-08-19): (node_id, violations) that survived a
    # corrective retry — the offending lines were stripped or the whole
    # description dropped; absence over fabrication.
    ungrounded: "list[tuple[str, list[str]]]" = field(default_factory=list)
    # (step_id, count): facts the translator failed to voice — their
    # lines came from the deterministic template floor (clause 5); the
    # text stays complete, the miss stays counted.
    unvoiced: "list[tuple[str, int]]" = field(default_factory=list)

    def fail(self, node_id: str, reason: str) -> None:
        self.failed.append(node_id)
        self.failed_reasons.append((node_id, reason))


def topological_step_order(nodes: dict, edges: list) -> "list[str]":
    """Transformation node_ids, every direct dependency before its dependent.

    DEPENDS_ON points dependent -> dependency, so emit in DFS post-order.
    Cycles (shouldn't exist; parser output is a DAG) are broken at the
    back-edge — the step is emitted once, grounded in its own fragment.
    """
    dependencies: "dict[str, list[str]]" = {}
    for e in edges:
        if e.edge_type == EdgeType.TRANSFORM_TO_TRANSFORM:
            dependencies.setdefault(e.source_id, []).append(e.target_id)

    ordered: "list[str]" = []
    done: "set[str]" = set()
    in_progress: "set[str]" = set()

    def visit(node_id: str) -> None:
        if node_id in done or node_id in in_progress:
            return
        in_progress.add(node_id)
        for dep in dependencies.get(node_id, []):
            visit(dep)
        in_progress.discard(node_id)
        done.add(node_id)
        ordered.append(node_id)

    for node_id, node in sorted(nodes.items()):
        if node.layer == NodeLayer.TRANSFORMATION:
            visit(node_id)
    return ordered


MAX_DICT_LINES = 30


def dictionary_for_step(
    step_id: str, nodes: dict, tech_map: "dict[str, list[str]]",
    columns_map: "dict[str, list[str]]", fragment: str,
) -> "list[str]":
    """Dictionary lines for the tables a step touches, plus only the
    COLUMNS the fragment actually references (whole-table column lists
    would drown the prompt). Pure selection — the dictionary text
    itself is the customer's own, from graph_nodes."""
    frag = (fragment or "").lower()
    lines: "list[str]" = []
    for table_id in sorted(tech_map.get(step_id, [])):
        table = nodes.get(table_id)
        if table is None:
            continue
        if (table.description or "").strip():
            lines.append(f"- {table.name}: {table.description.strip()}")
        for col_id in sorted(columns_map.get(table_id, [])):
            col = nodes.get(col_id)
            if col is None or not (col.description or "").strip():
                continue
            if col.name.lower() in frag:
                lines.append(f"  - {col.name}: {col.description.strip()}")
    return lines


def build_measure_prompt(
    name: str, expression: str, expression_type: str,
    report_name: str, dict_lines: "list[str] | None" = None,
) -> str:
    if dict_lines:
        entries = "\n".join(dict_lines[:MAX_DICT_LINES])
        dict_block = (
            "Data dictionary for the columns this DAX references "
            f"(translate identifiers using these):\n{entries}\n\n"
        )
    else:
        dict_block = ""
    return MEASURE_PROMPT.format(
        name=name, expression=expression or "(none)",
        expression_type=("calculated column" if expression_type == "calculated_column"
                         else "measure"),
        report_name=report_name or "(unknown)", dict_block=dict_block,
    )


def build_metric_prompt(metric_name: str, roots: "list[tuple[str, str]]", step_count: int) -> str:
    roots_block = "\n".join(f"- {n}: {d}" for n, d in roots) or "- (no described steps)"
    return METRIC_PROMPT.format(
        metric_name=metric_name, roots_block=roots_block, step_count=step_count
    )



_RETRY_NOTE = (
    "\n\nYour previous draft was REJECTED by an automatic grounding "
    "check for these violations:\n{violations}\n"
    "Rewrite it. Every value must appear in the SQL above; describe a "
    "column as a filter ONLY if it appears in a WHERE / JOIN ON / "
    "HAVING / CASE WHEN condition; drop any claim you cannot ground."
)


def _grounded_describe(
    describe, prompt: str, fragment: str,
    dict_lines: "list[str] | None",
) -> "tuple[str, list[str]]":
    """describe() + gate + ONE corrective retry + surgical fallback.
    Returns (text_or_empty, violations_removed)."""
    text = describe(prompt).strip()
    if not text:
        return "", []
    violations = grounding_violations(text, fragment, dict_lines)
    if not violations:
        return text, []
    note = _RETRY_NOTE.format(
        violations="\n".join(f"- {v}" for v in violations))
    try:
        retry = describe(prompt + note).strip()
    except Exception:  # noqa: BLE001 — retry is best-effort
        retry = ""
    if retry:
        text = retry
    return enforce_grounding(text, fragment, dict_lines)


def generate_descriptions(
    nodes_rows: "list[dict]",
    edges_rows: "list[dict]",
    describe: "Callable[[str], str]",
    cache: "dict[str, str] | None" = None,
) -> DescriptionResult:
    """Walk the DAG bottom-up; describe steps, then compose metrics.

    cache maps content_hash -> description and is mutated in place — the
    caller persists it (Delta table on Fabric, JSON locally). The cache
    is the ONLY regeneration authority: keys include PROMPT_VERSION and
    the exact inputs, so a description regenerates precisely when its
    SQL, its dependencies, or the prompt changed — an existing text on
    the node never blocks an upgrade from reaching it.
    """
    nodes = rows_to_nodes(nodes_rows)
    edges = rows_to_edges(edges_rows)
    cache = cache if cache is not None else {}
    result = DescriptionResult()

    dep_map: "dict[str, list[str]]" = {}
    for e in edges:
        if e.edge_type == EdgeType.TRANSFORM_TO_TRANSFORM:
            dep_map.setdefault(e.source_id, []).append(e.target_id)
    roots_map: "dict[str, list[str]]" = {}
    for e in edges:
        if e.edge_type == EdgeType.CANONICAL_TO_TRANSFORM:
            roots_map.setdefault(e.source_id, []).append(e.target_id)
    tech_map: "dict[str, list[str]]" = {}       # step -> touched tables
    columns_map: "dict[str, list[str]]" = {}    # table -> its columns
    for e in edges:
        if e.edge_type == EdgeType.TRANSFORM_TO_TECHNICAL:
            tech_map.setdefault(e.source_id, []).append(e.target_id)
        elif e.edge_type == EdgeType.TABLE_TO_COLUMN:
            columns_map.setdefault(e.source_id, []).append(e.target_id)

    described: "dict[str, str]" = {}

    for step_id in topological_step_order(nodes, edges):
        node = nodes[step_id]
        fragment = node.properties.get("sql_fragment", "")
        dep_names = [nodes[d].name for d in dep_map.get(step_id, []) if d in nodes]
        dict_lines = dictionary_for_step(
            step_id, nodes, tech_map, columns_map, fragment)
        key = step_content_hash(fragment, dep_names, dict_lines)
        if key in cache:
            described[step_id] = cache[key]
            result.descriptions[step_id] = cache[key]
            result.cache_hits += 1
            continue
        deps = [
            (nodes[d].name, described.get(d, ""))
            for d in dep_map.get(step_id, []) if d in nodes
        ]
        try:
            # Phase 2 (ADR 0044 clauses 2+5): the LLM translates typed
            # tree facts — it never sees the SQL statement. The ledger
            # guarantees completeness: unvoiced facts appear via the
            # deterministic template floor and are counted.
            tree = build_decision_tree(fragment)
            tr = translate_tree(tree, dict_lines, describe,
                                name=node.name, deps=deps)
            if tr.unvoiced:
                result.unvoiced.append((step_id, len(tr.unvoiced)))
            text, removed = enforce_grounding(tr.text, fragment, dict_lines)
        except Exception as err:  # noqa: BLE001 — one bad step must not kill the batch
            result.fail(step_id, f"generation_error: {type(err).__name__}: {err}"[:300])
            continue
        if removed:
            result.ungrounded.append((step_id, removed))
        if not text:
            result.fail(step_id, "grounded_to_empty: every generated line "
                                 "failed the grounding check")
            continue
        if _VAGUE_FILLERS.search(text):
            result.vague.append(step_id)
        if _RAW_IDENTIFIERS.search(text):
            result.jargon.append(step_id)
        cache[key] = text
        described[step_id] = text
        result.descriptions[step_id] = text
        result.generated += 1

    # Measures (ADR 0040): DAX is business logic — same treatment as SQL
    # steps. Independent of the step DAG; grounded in its own expression
    # plus the dictionary text of the columns it provably references
    # (MEASURE_TO_COLUMN edges — resolved, never guessed).
    measure_cols: "dict[str, list[str]]" = {}
    for e in edges:
        if e.edge_type == EdgeType.MEASURE_TO_COLUMN:
            measure_cols.setdefault(e.source_id, []).append(e.target_id)

    for node_id, node in sorted(nodes.items()):
        if node.layer != NodeLayer.MEASURE:
            continue
        expression = node.properties.get("dax_expression", "")
        if not expression:
            result.fail(node_id, "no_dax_expression: measure ingested "
                                 "without an expression")
            continue
        dict_lines = []
        for col_id in sorted(measure_cols.get(node_id, [])):
            col = nodes.get(col_id)
            if col is not None and (col.description or "").strip():
                dict_lines.append(f"- {col.name}: {col.description.strip()}")
        key = measure_content_hash(node.name, expression, dict_lines)
        if key in cache:
            result.descriptions[node_id] = cache[key]
            result.cache_hits += 1
            continue
        prompt = build_measure_prompt(
            node.name, expression,
            node.properties.get("expression_type", "measure"),
            node.properties.get("report_name", ""), dict_lines,
        )
        try:
            text, removed = _grounded_describe(
                describe, prompt, expression, dict_lines)
        except Exception as err:  # noqa: BLE001 — one bad measure must not kill the batch
            result.fail(node_id, f"generation_error: {type(err).__name__}: {err}"[:300])
            continue
        if removed:
            result.ungrounded.append((node_id, removed))
        if not text:
            result.fail(node_id, "grounded_to_empty: every generated line "
                                 "failed the grounding check")
            continue
        if _VAGUE_FILLERS.search(text):
            result.vague.append(node_id)
        if _RAW_IDENTIFIERS.search(text):
            result.jargon.append(node_id)
        cache[key] = text
        result.descriptions[node_id] = text
        result.generated += 1

    # Metrics: composed from ROOT step descriptions (raw roots-only edges)
    step_count_by_metric: "dict[str, int]" = {}
    for node_id, node in nodes.items():
        if node.layer == NodeLayer.TRANSFORMATION:
            metric_id = node.properties.get("metric_id", "")
            step_count_by_metric[metric_id] = step_count_by_metric.get(metric_id, 0) + 1

    for node_id, node in sorted(nodes.items()):
        if node.layer != NodeLayer.CANONICAL:
            continue
        metric_id = node_id.replace("canonical:", "")
        roots = [
            (nodes[r].name, described.get(r, ""))
            for r in roots_map.get(node_id, []) if r in nodes
        ]
        if not roots:
            result.fail(node_id, "no_root_steps: metric node has no "
                                 "root-step edges to compose from")
            continue
        step_count = step_count_by_metric.get(metric_id, len(roots))
        key = metric_content_hash(node.name, roots, step_count)
        if key in cache:
            result.descriptions[node_id] = cache[key]
            result.cache_hits += 1
            continue
        prompt = build_metric_prompt(node.name, roots, step_count)
        roots_ground = "\n".join(d for _, d in roots)
        try:
            text, removed = _grounded_describe(
                describe, prompt, roots_ground, None)
        except Exception as err:  # noqa: BLE001
            result.fail(node_id, f"generation_error: {type(err).__name__}: {err}"[:300])
            continue
        if removed:
            result.ungrounded.append((node_id, removed))
        if not text:
            result.fail(node_id, "grounded_to_empty: every generated line "
                                 "failed the grounding check")
            continue
        if _VAGUE_FILLERS.search(text):
            result.vague.append(node_id)
        if _RAW_IDENTIFIERS.search(text):
            result.jargon.append(node_id)
        cache[key] = text
        result.descriptions[node_id] = text
        result.generated += 1

    return result
