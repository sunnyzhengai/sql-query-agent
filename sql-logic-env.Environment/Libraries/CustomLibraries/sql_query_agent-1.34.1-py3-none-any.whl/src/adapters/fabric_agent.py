"""Fabric Data Agent programmatic client.

Calls the Fabric Data Agent via the MCP (Model Context Protocol) endpoint
to generate business descriptions by leveraging the agent's graph traversal
and persona instructions.

The agent produces better descriptions than direct LLM calls because it:
- Traverses the knowledge graph to find relevant sql_fragments
- Applies the persona instructions (business-friendly translation)
- Uses the SQL-to-business translation table
- Produces structured, criteria-focused output

Protocol: JSON-RPC over the MCP endpoint
Endpoint: POST https://api.fabric.microsoft.com/v1/mcp/workspaces/{workspaceId}/dataagents/{agentId}/agent
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import Any, Callable, Optional

logger = logging.getLogger(__name__)

# AAD tokens expire after ~1 hour. Refresh proactively before expiry.
TOKEN_REFRESH_INTERVAL_SECONDS = 45 * 60  # refresh every 45 minutes


@dataclass
class AgentResponse:
    """Response from the Data Agent."""
    question: str
    answer: str
    status: str  # "success" or "failed"
    error: str = ""


class FabricAgentClient:
    """Programmatic client for the Fabric Data Agent via MCP protocol.

    Sends natural language questions using JSON-RPC format and captures
    the agent's responses for use as metadata descriptions.

    Authentication: uses mssparkutils.credentials.getToken() in Fabric,
    or an explicit access token for testing.
    """

    BASE_URL = "https://api.fabric.microsoft.com/v1"

    def __init__(
        self,
        workspace_id: str,
        agent_id: str,
        tool_name: str = "",
        access_token: str = "",
        token_provider: "Optional[Callable[[], str]]" = None,
    ) -> None:
        """token_provider is the right choice for long runs: it is re-invoked
        per request (and forced on 401), so >1hr description loops survive
        token expiry. A static access_token never refreshes — tests only.
        Pass e.g.: token_provider=lambda: notebookutils.credentials.getToken(
        "https://api.fabric.microsoft.com")."""
        self.workspace_id = workspace_id
        self.agent_id = agent_id
        self.tool_name = tool_name  # discovered via tools/list
        self._token_provider = token_provider
        self._explicit_token = access_token  # explicitly passed token (no refresh)
        self._cached_token = ""
        self._token_fetched_at = 0.0
        self._endpoint = (
            f"{self.BASE_URL}/mcp/workspaces/{workspace_id}"
            f"/dataagents/{agent_id}/agent"
        )

    def _get_token(self) -> str:
        if self._token_provider is not None:
            return self._token_provider()
        if self._explicit_token:
            return self._explicit_token

        # Refresh cached token if it's older than the refresh interval
        elapsed = time.time() - self._token_fetched_at
        if self._cached_token and elapsed < TOKEN_REFRESH_INTERVAL_SECONDS:
            return self._cached_token

        # In Fabric notebooks, mssparkutils is injected as a global,
        # not an importable module. Try the global first, then import.
        import builtins
        _mssparkutils = getattr(builtins, "mssparkutils", None)
        if _mssparkutils is None:
            try:
                import mssparkutils as _mssparkutils  # type: ignore
            except ImportError:
                _mssparkutils = None
        if _mssparkutils is None:
            raise RuntimeError(
                "mssparkutils not available. Run in a Fabric Notebook "
                "or pass access_token explicitly."
            )
        self._cached_token = _mssparkutils.credentials.getToken("https://api.fabric.microsoft.com")
        self._token_fetched_at = time.time()
        if elapsed > 0:
            logger.info("Refreshed AAD token (previous was %.0f minutes old)", elapsed / 60)
        return self._cached_token

    def _get_headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self._get_token()}",
            "Content-Type": "application/json",
        }

    def _mcp_call(self, method: str, params: dict[str, Any], request_id: str = "1") -> dict[str, Any]:
        """Send a JSON-RPC request to the MCP endpoint."""
        import requests

        payload = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
            "id": request_id,
        }

        resp = requests.post(
            self._endpoint,
            headers=self._get_headers(),
            json=payload,
            timeout=120,
        )

        if resp.status_code in (401, 403):
            # Token likely expired mid-run: force a refresh and retry ONCE.
            # Without this, long description loops died with auth failures
            # disguised as per-metric content failures (audit 2026-08-15).
            logger.warning(
                "MCP endpoint returned %d — forcing token refresh and retrying once",
                resp.status_code,
            )
            self._cached_token = ""
            self._token_fetched_at = 0.0
            resp = requests.post(
                self._endpoint,
                headers=self._get_headers(),
                json=payload,
                timeout=120,
            )
            if resp.status_code in (401, 403):
                raise RuntimeError(
                    f"MCP endpoint returned {resp.status_code} even after token refresh — "
                    f"authentication is broken, not the content: {resp.text[:200]}"
                )

        if resp.status_code != 200:
            raise RuntimeError(f"MCP endpoint returned {resp.status_code}: {resp.text[:200]}")

        return resp.json()

    def discover_tool_name(self) -> str:
        """Discover the Data Agent's tool name via tools/list.

        The tool name is auto-generated from the agent's display name
        (e.g., "DataAgent_SQL_Query_Agent") and is needed for tools/call.
        """
        result = self._mcp_call("tools/list", {})

        tools = result.get("result", {}).get("tools", [])
        if tools:
            self.tool_name = tools[0]["name"]
            logger.info("Discovered tool name: %s", self.tool_name)
            return self.tool_name

        raise RuntimeError("No tools found on the Data Agent")

    def query(self, question: str) -> AgentResponse:
        """Send a question to the Data Agent and return the response.

        Args:
            question: Natural language question for the agent.

        Returns:
            AgentResponse with the agent's answer.
        """
        if not self.tool_name:
            self.discover_tool_name()

        try:
            result = self._mcp_call(
                "tools/call",
                {
                    "name": self.tool_name,
                    "arguments": {"userQuestion": question},
                },
                request_id="q",
            )

            # Extract answer from MCP response
            answer = self._extract_answer(result)

            if answer:
                return AgentResponse(
                    question=question,
                    answer=answer,
                    status="success",
                )
            else:
                return AgentResponse(
                    question=question,
                    answer="",
                    status="failed",
                    error="Empty response from agent",
                )

        except Exception as e:  # noqa: BLE001 — failure becomes AgentResponse(status=failed) with the error
            return AgentResponse(
                question=question,
                answer="",
                status="failed",
                error=str(e),
            )

    def _extract_answer(self, response: dict[str, Any]) -> str:
        """Extract the answer text from the MCP JSON-RPC response."""
        result = response.get("result", {})

        # MCP tools/call format: result.content[0].text
        content = result.get("content", [])
        if isinstance(content, list) and content:
            first = content[0]
            if isinstance(first, dict):
                return first.get("text", "")
            return str(first)

        # Fallback
        if isinstance(result, str):
            return result

        return str(result) if result else ""

    def generate_metric_description(self, metric_name: str) -> AgentResponse:
        """Generate a business description for a metric using the Data Agent.

        Uses a question format that triggers the agent to read sql_fragments
        and produce structured, criteria-focused output.
        """
        question = (
            f"For the report {metric_name}, write a catalog description in this exact format:\n"
            f"First, one sentence stating the business purpose of the report "
            f"(why it exists, who uses it, what decisions it supports — "
            f"do NOT list columns or fields the report contains).\n\n"
            f"If the SQL uses CTEs or subqueries, add a blank line then 'Data flow:' "
            f"followed by a bulleted list of each cohort or step. For each step, "
            f"describe what it produces AND include the filters/criteria applied in that step "
            f"(e.g., 'Stroke cohort — identifies patients with ICD-10 codes I61, I63, I62, I67; "
            f"filters to valid patients only'). "
            f"Nest sub-filters under each step where they belong.\n\n"
            f"If the SQL has no CTEs or subqueries, instead add a blank line then "
            f"'Filtered by:' followed by a flat bulleted list of all filters and criteria.\n\n"
            f"No greetings, no preamble, no markdown headers, no bold text. "
            f"Start directly with the purpose sentence."
        )
        return self.query(question)

    def generate_descriptions_bulk(
        self,
        metric_names: list[str],
        batch_log_interval: int = 10,
    ) -> dict[str, AgentResponse]:
        """Generate descriptions for multiple metrics.

        Args:
            metric_names: List of metric names to describe.
            batch_log_interval: Log progress every N metrics.

        Returns:
            Dict of metric_name -> AgentResponse.
        """
        results: dict[str, AgentResponse] = {}
        succeeded = 0
        failed = 0

        # Discover tool name once
        if not self.tool_name:
            self.discover_tool_name()

        logger.info("Generating descriptions for %d metrics via Data Agent", len(metric_names))

        for i, name in enumerate(metric_names):
            response = self.generate_metric_description(name)
            results[name] = response

            if response.status == "success":
                succeeded += 1
            else:
                failed += 1
                logger.warning("Failed for %s: %s", name, response.error)

            if (i + 1) % batch_log_interval == 0:
                logger.info("  Processed %d/%d metrics (%d succeeded, %d failed)",
                           i + 1, len(metric_names), succeeded, failed)

        logger.info("Done: %d succeeded, %d failed out of %d",
                    succeeded, failed, len(metric_names))
        return results
