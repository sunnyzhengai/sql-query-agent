"""The work wheel's assets: the ScriptDom DLL and its own manifest (Brief_Packaging)."""
